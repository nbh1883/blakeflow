# Assets

This folder is where user-provided brand template files should be placed.

## Supported File Types

| File | Description |
|------|-------------|
| `*.pptx` | Standard PowerPoint file — can be opened directly with python-pptx |
| `*.potx` | PowerPoint template — must be converted first (see below) |
| `*.png`, `*.jpg`, `*.svg` | Logo files for placement on slides |

## Adding a Template

If the user provides a brand template file:

1. Place it in this `assets/` folder
2. If it's a `.potx`, convert it first:
   ```bash
   python scripts/convert_potx.py assets/template.potx assets/template_fixed.pptx
   ```
3. Open with python-pptx:
   ```python
   from pptx import Presentation
   prs = Presentation('assets/template_fixed.pptx')
   ```

## No Template?

If no template is provided, build from scratch using the patterns in `references/pptx-templates.md` and the brand colors/fonts collected during elicitation.
