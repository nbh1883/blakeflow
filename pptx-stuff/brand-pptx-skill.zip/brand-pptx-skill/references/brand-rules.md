# Brand Rules & Profile Encoding

## BrandProfile Schema

After elicitation, encode all collected brand information into this Python dict. Pass it into every python-pptx function so all slides share a single source of truth.

```python
from pptx.dml.color import RGBColor
from pptx.util import Pt

def hex_to_rgb(hex_str):
    """Convert '#RRGGBB' or 'RRGGBB' to RGBColor."""
    h = hex_str.lstrip('#')
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))

# ── Populated from elicitation ──────────────────────────────────────────────
BRAND = {
    # Colors
    "primary":     hex_to_rgb("#REPLACE_PRIMARY"),      # Dominant color (60-70% weight)
    "secondary":   hex_to_rgb("#REPLACE_SECONDARY"),    # Accent / highlights
    "background":  hex_to_rgb("#FFFFFF"),               # Slide background
    "text_dark":   hex_to_rgb("#1A1A1A"),               # Body text on light bg
    "text_light":  hex_to_rgb("#FFFFFF"),               # Body text on dark bg
    "text_muted":  hex_to_rgb("#666666"),               # Captions, footnotes

    # Typography
    "font":        "Arial",                             # Primary font
    "font_alt":    "Arial",                             # Fallback font
    "title_size":  Pt(36),
    "header_size": Pt(22),
    "body_size":   Pt(14),
    "caption_size": Pt(10),

    # Structure
    "title_slide_bg":    "primary",   # "primary", "secondary", or "#HEXCODE"
    "content_slide_bg":  "background",
    "divider_bg":        "primary",
    "footer_text":       "",          # e.g. "CONFIDENTIAL" or "" for none
    "logo_path":         None,        # Path to logo file or None
    "logo_placement":    "bottom-left",  # "bottom-left", "top-right", "title-only"
}
```

---

## Color Rules

These rules apply to every brand — they're structural, not brand-specific:

| Rule | Description |
|------|-------------|
| **Dominance** | Primary color carries 60–70% visual weight per composition |
| **Accent sparingly** | Secondary color for highlights, subheadings, interactive elements — not backgrounds of large areas |
| **Dark slide text** | Always use `text_light` (white or near-white) on dark backgrounds |
| **Light slide text** | Always use `text_dark` on light backgrounds — never pure `#000000` unless brand specifies |
| **Consistency** | Never introduce colors outside the brand profile without user approval |
| **No rainbow charts** | Chart series use primary, secondary, and muted tones — not arbitrary colors |

### Deriving a Secondary Color (if none provided)

If the user only provides one brand color, derive a secondary using one of these strategies:
1. **Complementary tint**: Lighten the primary by 40% for a softer accent
2. **Warm/cool contrast**: If primary is warm, use a cool neutral; if cool, use a warm tone
3. **Neutral pairing**: A medium gray (`#6B7280`) works as a universal secondary for any primary

Always tell the user what you chose: "Since you only gave me one color, I've paired it with [DERIVED] as the accent — let me know if you'd prefer something else."

---

## Typography Rules

| Element | Size | Weight | Case |
|---------|------|--------|------|
| Slide title | 32–44pt | Bold | Brand preference (ALL CAPS or Title Case) |
| Section header | 20–24pt | Bold | Match slide title case |
| Body text | 12–16pt | Regular | Sentence case |
| Stat callout | 48–72pt | Bold | — |
| Caption / footnote | 9–11pt | Regular | Sentence case |

**Font fallback chain**: Always use the brand font. If not a standard Office font, fall back to Arial. Never use Calibri, Times New Roman, or Comic Sans unless the brand explicitly specifies them.

---

## Layout Safe Zones

Use these EMU boundaries for content placement to avoid footer/logo overlap:

| Zone | EMU | Approx Inches |
|------|-----|---------------|
| Left margin | 457,200 | 0.5" |
| Top margin (below title area) | 1,371,600 | 1.5" |
| Right margin | 11,887,200 max | 0.5" from right |
| Bottom margin | 6,400,800 max | 0.5" from bottom |
| Slide width | 12,192,000 | 13.33" |
| Slide height | 6,858,000 | 7.5" |

---

## Slide Type Patterns

### Title Slide

- Background: `BRAND["primary"]` (full bleed)
- Title text: `BRAND["text_light"]`, 40–44pt Bold
- Subtitle: `BRAND["text_light"]` at 70% opacity, 18–22pt Regular
- Logo (if provided): centered or top-left, white/light variant
- No footer on title slide

### Content Slide

- Background: `BRAND["background"]` (usually white)
- Title: `BRAND["primary"]`, 32–36pt Bold, top-left
- Body: `BRAND["text_dark"]`, 12–14pt Regular
- Accent bar or icon: `BRAND["secondary"]`
- Footer (if configured): `BRAND["text_muted"]`, 9pt, bottom-right

### Section Divider

- Background: `BRAND["primary"]` or `BRAND["divider_bg"]`
- Section title: `BRAND["text_light"]`, 36–40pt Bold
- Optional subtitle: `BRAND["text_light"]` at 70% opacity, 18pt
- No body content

### Closing Slide

- Split layout: Primary color left half, white right half
- Left: Logo + "Thank You" or brand tagline
- Right: Contact info, next steps, or QR code area

---

## Do's and Don'ts

### ✅ Do

- Use `BRAND["primary"]` as the dominant color in every slide
- Use `BRAND["secondary"]` for accents, icon circles, teal bars, highlights
- Use `BRAND["text_dark"]` for body text on light backgrounds
- Use `BRAND["text_light"]` for ALL text on dark/primary-colored backgrounds
- Keep text sizes consistent — define once in BRAND dict, reference everywhere
- Add visual elements (icons, shapes, callouts) to every content slide

### ❌ Don't

- Introduce colors not in the BRAND dict without user approval
- Use pure black (`#000000`) for backgrounds — use `BRAND["primary"]` for dark slides
- Use secondary color as the dominant (60-70%) color — it's always the accent
- Create text-only slides — always add at least one shape, icon, or callout
- Place content outside the safe zone boundaries
- Add decorative accent lines under slide titles

---

## Common Patterns (python-pptx Snippets)

### Brand Card (Rounded Rectangle with Accent Bar)

```python
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.util import Emu, Pt
from pptx.oxml.ns import qn
import lxml.etree as etree

def add_brand_card(slide, brand, left, top, width, height, title, body):
    """Add a branded card with an accent bar on top."""
    # Card background
    card = slide.shapes.add_shape(
        1,  # MSO_SHAPE.RECTANGLE
        left, top, width, height
    )
    card.fill.solid()
    card.fill.fore_color.rgb = brand["background"]
    card.line.color.rgb = brand["secondary"]
    card.line.width = Emu(12700)  # 1pt

    # Accent bar
    bar = slide.shapes.add_shape(
        1,
        left, top, width, Emu(60000)
    )
    bar.fill.solid()
    bar.fill.fore_color.rgb = brand["secondary"]
    bar.line.fill.background()

    # Title text
    txb = slide.shapes.add_textbox(
        left + Emu(91440), top + Emu(120000),
        width - Emu(182880), Emu(400000)
    )
    p = txb.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = title
    run.font.bold = True
    run.font.size = brand["header_size"]
    run.font.color.rgb = brand["primary"]
    run.font.name = brand["font"]

    # Body text
    txb2 = slide.shapes.add_textbox(
        left + Emu(91440), top + Emu(530000),
        width - Emu(182880), height - Emu(620000)
    )
    txb2.text_frame.word_wrap = True
    p2 = txb2.text_frame.paragraphs[0]
    run2 = p2.add_run()
    run2.text = body
    run2.font.size = brand["body_size"]
    run2.font.color.rgb = brand["text_dark"]
    run2.font.name = brand["font"]
```

### Numbered Step Circle

```python
def add_numbered_circle(slide, brand, left, top, number):
    """Add a numbered circle in the secondary brand color."""
    size = Emu(400000)
    circle = slide.shapes.add_shape(9, left, top, size, size)  # 9 = OVAL
    circle.fill.solid()
    circle.fill.fore_color.rgb = brand["secondary"]
    circle.line.fill.background()
    tf = circle.text_frame
    tf.paragraphs[0].alignment = 2  # PP_ALIGN.CENTER
    run = tf.paragraphs[0].add_run()
    run.text = str(number)
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.color.rgb = brand["text_light"]
    run.font.name = brand["font"]
```

### Stat Callout

```python
def add_stat_callout(slide, brand, left, top, width, number, label):
    """Add a large-number stat callout."""
    # Number
    num_box = slide.shapes.add_textbox(left, top, width, Emu(900000))
    p = num_box.text_frame.paragraphs[0]
    p.alignment = 2  # CENTER
    run = p.add_run()
    run.text = number
    run.font.size = Pt(60)
    run.font.bold = True
    run.font.color.rgb = brand["primary"]
    run.font.name = brand["font"]

    # Label
    lbl_box = slide.shapes.add_textbox(left, top + Emu(950000), width, Emu(350000))
    p2 = lbl_box.text_frame.paragraphs[0]
    p2.alignment = 2  # CENTER
    run2 = p2.add_run()
    run2.text = label
    run2.font.size = brand["caption_size"]
    run2.font.color.rgb = brand["text_muted"]
    run2.font.name = brand["font"]
```

### Title Slide (Scratch)

```python
def add_title_slide(prs, brand, title, subtitle="", author="", date=""):
    """Add a full-bleed primary-color title slide."""
    from pptx.util import Inches
    slide_layout = prs.slide_layouts[6]  # Blank layout
    slide = prs.slides.add_slide(slide_layout)

    # Background
    bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = brand["primary"]
    bg.line.fill.background()

    # Title
    title_box = slide.shapes.add_textbox(
        Emu(600000), Emu(2200000), Emu(10800000), Emu(1200000)
    )
    title_box.text_frame.word_wrap = True
    p = title_box.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = title
    run.font.size = Pt(40)
    run.font.bold = True
    run.font.color.rgb = brand["text_light"]
    run.font.name = brand["font"]

    # Subtitle
    if subtitle:
        sub_box = slide.shapes.add_textbox(
            Emu(600000), Emu(3500000), Emu(10800000), Emu(800000)
        )
        p2 = sub_box.text_frame.paragraphs[0]
        run2 = p2.add_run()
        run2.text = subtitle
        run2.font.size = Pt(18)
        run2.font.color.rgb = brand["text_light"]
        run2.font.name = brand["font"]

    return slide
```

---

## File Naming Convention

- `[BrandName]_[Topic]_[Version].pptx` — for branded deliverables
- Always include the brand name in the filename so it's identifiable
