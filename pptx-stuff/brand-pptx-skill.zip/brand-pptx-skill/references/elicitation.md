# Brand Elicitation Protocol

## Overview

This document defines how the LLM should collect brand information from a user before building any presentation. The goal is to gather exactly what's needed — no more, no less — in a conversational, friendly way.

**Never skip this step.** Building a deck with guessed colors or fonts wastes everyone's time.

---

## When to Trigger Elicitation

Trigger elicitation when ALL of the following are true:
1. The user has asked for a branded presentation
2. No brand profile exists in the conversation context
3. The user has not provided a `.pptx` or `.potx` template file

If the user provides a template file, you can skip most elicitation — extract colors, fonts, and layout from the template instead, and only ask about anything that can't be inferred.

---

## Elicitation Script

Use this exact conversational flow. Ask questions in batches — don't fire them one at a time. Group related questions together.

---

### Opening

Start with this or a close variant:

> Before I build your deck, I need to capture your brand identity so the slides look like *you*. I'll ask a few quick questions — most have simple answers.

---

### Batch 1: Colors (Required)

Ask all three color questions together:

> **Colors — what are your brand colors?**
>
> 1. **Primary color** — the dominant color used most (e.g., your main brand navy, red, or green). Hex code preferred, but a color name works too.
> 2. **Secondary color** — a supporting color used for accents, subheadings, or highlights.
> 3. **Background** — what color are most of your slides? (Usually white, off-white, or dark/navy)
>
> If you have a full brand palette, feel free to paste the whole thing.

**Parsing rules:**
- Accept hex codes (`#132E53`), RGB, color names, or descriptions ("dark navy blue")
- If only one color given, treat it as primary and derive a complementary secondary
- If no background given, default to white (`#FFFFFF`) for light mode or the primary color for dark mode
- Always confirm: "Got it — I'll use [PRIMARY] as your dominant color, [SECONDARY] as accent, [BACKGROUND] for slide backgrounds."

---

### Batch 2: Typography (Required)

> **Fonts — what fonts does your brand use?**
>
> - **Presentation font** (the one you use in PowerPoint/Google Slides) — if unsure, Arial, Calibri, or your logo font name works.
> - Any **specific size rules**? (e.g., "titles at 36pt bold" or "body text at 12pt")
>
> If you don't have a brand font, I'll pick one that fits your color palette.

**Parsing rules:**
- If the font is not a standard Office font (Arial, Calibri, Georgia, etc.), default to Arial as a safe fallback but note it
- If no sizes given, use the defaults in `brand-rules.md`

---

### Batch 3: Logo (Optional but Recommended)

> **Logo — do you have a logo file you'd like on the slides?**
>
> - You can upload a `.png`, `.svg`, or `.jpg` here, or skip if you don't need a logo on the slides.
> - If you upload one, where should it go? (e.g., bottom-left of every slide, top-right of title slide only)

**Parsing rules:**
- If logo provided: note file name, planned placement
- If no logo: note "no logo" — do not fabricate or use a placeholder
- Common placements: bottom-left of all slides, top-right corner, title slide only

---

### Batch 4: Slide Structure (Required)

> **Slide structure — how should the deck be organized?**
>
> 1. **Title slide**: Should it be dark (your primary color as full background) or light (white background)?
> 2. **Content slides**: Dark or light background?
> 3. **Section dividers**: Do you want divider slides between sections? If yes, same color as title slide?
> 4. **Footer**: Should every slide have a footer? (e.g., "CONFIDENTIAL", your company name, or nothing)
>
> Quick answers are fine — "dark title, light content, yes dividers, no footer" works perfectly.

**Parsing rules:**
- Infer as much as possible from the answer
- Default: dark title slide (primary color), light content slides (white), section dividers (primary color), no footer unless specified
- If "confidential" footer requested, place bottom-right

---

### Batch 5: Content & Tone (Optional)

> **Content — what's the deck about, and who's the audience?**
>
> - **Topic**: What is this presentation covering?
> - **Audience**: Who will see this? (e.g., executives, clients, internal team)
> - **Tone**: Professional and formal? Friendly and casual? Data-heavy? Storytelling?
> - **Slide count**: Roughly how many slides do you need?
>
> (Skip anything that doesn't apply — I can also work from an outline you paste.)

---

### Batch 6: Existing Template (Optional)

> **Do you have an existing PowerPoint template (.pptx or .potx)?**
>
> If yes, upload it here and I'll use it as the base — inheriting your master layouts, backgrounds, and embedded branding automatically.
>
> If no, I'll build from scratch using your brand colors and fonts.

**Parsing rules:**
- If `.potx` provided: run `scripts/convert_potx.py` to convert before opening with python-pptx
- If `.pptx` provided: open directly
- Extract colors, fonts, and layout from template — skip or confirm elicited values

---

## Minimum Required Info

To proceed with deck creation, at minimum you need:

| Field | Required? | Default if Missing |
|-------|-----------|-------------------|
| Primary color | ✅ Yes | Cannot proceed — must ask |
| Secondary color | Recommended | Derive from primary |
| Background color | Recommended | White `#FFFFFF` |
| Font | Recommended | Arial |
| Slide structure | Recommended | Dark title, light content |
| Topic / content | ✅ Yes | Cannot proceed — must ask |

---

## Confirmation Step

After collecting all answers, summarize before building:

> Here's your brand profile — let me know if anything needs adjusting before I start:
>
> - **Primary color**: [HEX] ([Name])
> - **Secondary / accent color**: [HEX] ([Name])
> - **Background**: [HEX or description]
> - **Font**: [Font name], titles at [Xpt bold], body at [Xpt regular]
> - **Logo**: [Uploaded as filename / No logo / Bottom-left placement]
> - **Slide structure**: [Dark title, light content, section dividers yes/no, footer text or none]
> - **Topic**: [Brief description]
> - **Tone**: [Tone description]
> - **Slide count**: [Number or "flexible"]
>
> Ready to build — or any changes?

Wait for confirmation before writing code.

---

## Handling Incomplete Answers

If the user gives vague answers:

| Vague Answer | How to Handle |
|--------------|---------------|
| "Just use our brand colors" | Ask: "Could you share the hex codes or a screenshot of your brand palette?" |
| "Match our website" | Ask: "What's your website URL?" — then extract colors programmatically if possible |
| "Standard fonts" | Default to Arial — confirm with user |
| "Make it look professional" | Use a clean dark/light structure with the primary color as dominant — no need to ask more |
| "Whatever looks good" | You have creative latitude — pick a palette that fits the topic, document your choices |

---

## Storing the Brand Profile

Once elicitation is complete, encode the results into a `BrandProfile` dict for use in python-pptx code. See `references/brand-rules.md` for the exact schema and encoding rules.
