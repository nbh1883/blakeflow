# PPTX Template Patterns

## Overview

This document covers how to build presentations using python-pptx, whether starting from scratch or using a provided template. All patterns use the `BRAND` dict defined in `brand-rules.md`.

---

## Installing Dependencies

```bash
pip install python-pptx Pillow --break-system-packages
```

---

## Two Approaches

| Approach | When to Use |
|----------|-------------|
| **From template** | User provided a `.pptx` or `.potx` file — inherit master layouts |
| **From scratch** | No template — build everything programmatically |

---

## Approach A: From a User-Provided Template

### Opening a .pptx Template

```python
from pptx import Presentation

prs = Presentation('user_template.pptx')
```

### Opening a .potx Template

python-pptx cannot open `.potx` files directly. Convert first:

```python
# Run this before opening:
# python scripts/convert_potx.py template.potx template_fixed.pptx

prs = Presentation('template_fixed.pptx')
```

Or use the bundled convert script (see `scripts/convert_potx.py`).

### Exploring Template Layouts

Before adding slides, understand what's available:

```python
for mi, master in enumerate(prs.slide_masters):
    print(f"Master {mi}:")
    for li, layout in enumerate(master.slide_layouts):
        print(f"  Layout {li}: {layout.name}")
```

### Adding Slides from Template Layouts

```python
# Use the first content layout (usually index 1 in most templates)
layout = prs.slide_masters[0].slide_layouts[1]
slide = prs.slides.add_slide(layout)
```

### Setting Title via Placeholder

```python
from pptx.util import Pt
from pptx.dml.color import RGBColor

for ph in slide.placeholders:
    if ph.placeholder_format.idx == 0:  # Title placeholder
        ph.text = "SLIDE TITLE HERE"
        for para in ph.text_frame.paragraphs:
            for run in para.runs:
                run.font.name = BRAND["font"]
                run.font.size = BRAND["title_size"]
                run.font.bold = True
                run.font.color.rgb = BRAND["primary"]
        break
```

---

## Approach B: Building from Scratch

### Initialization

```python
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

prs = Presentation()
prs.slide_width = Emu(12192000)   # 13.33"
prs.slide_height = Emu(6858000)   # 7.5"
```

### Adding a Blank Slide

```python
blank_layout = prs.slide_layouts[6]  # Blank
slide = prs.slides.add_slide(blank_layout)
```

### Full Title Slide (from scratch)

```python
def make_title_slide(prs, brand, title, subtitle=""):
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # Full-bleed primary background
    bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = brand["primary"]
    bg.line.fill.background()

    # Accent block (secondary color strip, left side)
    accent = slide.shapes.add_shape(1, 0, 0, Emu(600000), prs.slide_height)
    accent.fill.solid()
    accent.fill.fore_color.rgb = brand["secondary"]
    accent.line.fill.background()

    # Title
    txb = slide.shapes.add_textbox(Emu(800000), Emu(2000000), Emu(10500000), Emu(1400000))
    txb.text_frame.word_wrap = True
    p = txb.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = title
    run.font.bold = True
    run.font.size = Pt(40)
    run.font.color.rgb = brand["text_light"]
    run.font.name = brand["font"]

    # Subtitle
    if subtitle:
        sub = slide.shapes.add_textbox(Emu(800000), Emu(3500000), Emu(10500000), Emu(700000))
        p2 = sub.text_frame.paragraphs[0]
        run2 = p2.add_run()
        run2.text = subtitle
        run2.font.size = Pt(18)
        run2.font.color.rgb = brand["text_light"]
        run2.font.name = brand["font"]

    return slide
```

### Content Slide (Two-Column)

```python
def make_two_column_slide(prs, brand, title, left_content, right_content):
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # White background
    bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = brand["background"]
    bg.line.fill.background()

    # Title bar
    title_bar = slide.shapes.add_textbox(
        Emu(457200), Emu(300000), Emu(11200000), Emu(700000)
    )
    p = title_bar.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = title
    run.font.bold = True
    run.font.size = brand["title_size"]
    run.font.color.rgb = brand["primary"]
    run.font.name = brand["font"]

    # Left column
    left = slide.shapes.add_textbox(Emu(457200), Emu(1300000), Emu(5400000), Emu(5000000))
    left.text_frame.word_wrap = True
    p2 = left.text_frame.paragraphs[0]
    run2 = p2.add_run()
    run2.text = left_content
    run2.font.size = brand["body_size"]
    run2.font.color.rgb = brand["text_dark"]
    run2.font.name = brand["font"]

    # Right column
    right = slide.shapes.add_textbox(Emu(6400000), Emu(1300000), Emu(5400000), Emu(5000000))
    right.text_frame.word_wrap = True
    p3 = right.text_frame.paragraphs[0]
    run3 = p3.add_run()
    run3.text = right_content
    run3.font.size = brand["body_size"]
    run3.font.color.rgb = brand["text_dark"]
    run3.font.name = brand["font"]

    return slide
```

### Section Divider Slide

```python
def make_section_divider(prs, brand, section_title, subtitle=""):
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # Full-bleed primary background
    bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = brand["primary"]
    bg.line.fill.background()

    # Section number accent (optional horizontal rule in secondary color)
    rule = slide.shapes.add_shape(1, Emu(457200), Emu(3000000), Emu(2000000), Emu(40000))
    rule.fill.solid()
    rule.fill.fore_color.rgb = brand["secondary"]
    rule.line.fill.background()

    # Section title
    txb = slide.shapes.add_textbox(Emu(457200), Emu(2300000), Emu(11000000), Emu(1000000))
    p = txb.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = section_title
    run.font.bold = True
    run.font.size = Pt(38)
    run.font.color.rgb = brand["text_light"]
    run.font.name = brand["font"]

    if subtitle:
        sub = slide.shapes.add_textbox(Emu(457200), Emu(3200000), Emu(11000000), Emu(600000))
        p2 = sub.text_frame.paragraphs[0]
        run2 = p2.add_run()
        run2.text = subtitle
        run2.font.size = Pt(16)
        run2.font.color.rgb = brand["text_light"]
        run2.font.name = brand["font"]

    return slide
```

### Closing Slide

```python
def make_closing_slide(prs, brand, headline="Thank You", contact_info=""):
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # Left half — primary color
    left_bg = slide.shapes.add_shape(1, 0, 0, Emu(5500000), prs.slide_height)
    left_bg.fill.solid()
    left_bg.fill.fore_color.rgb = brand["primary"]
    left_bg.line.fill.background()

    # Right half — white/background
    right_bg = slide.shapes.add_shape(1, Emu(5500000), 0, Emu(6692000), prs.slide_height)
    right_bg.fill.solid()
    right_bg.fill.fore_color.rgb = brand["background"]
    right_bg.line.fill.background()

    # Left headline
    hl = slide.shapes.add_textbox(Emu(600000), Emu(2800000), Emu(4600000), Emu(1000000))
    p = hl.text_frame.paragraphs[0]
    run = p.add_run()
    run.text = headline
    run.font.bold = True
    run.font.size = Pt(36)
    run.font.color.rgb = brand["text_light"]
    run.font.name = brand["font"]

    # Right contact info
    if contact_info:
        ct = slide.shapes.add_textbox(Emu(5800000), Emu(2500000), Emu(5800000), Emu(2000000))
        ct.text_frame.word_wrap = True
        p2 = ct.text_frame.paragraphs[0]
        run2 = p2.add_run()
        run2.text = contact_info
        run2.font.size = Pt(14)
        run2.font.color.rgb = brand["text_dark"]
        run2.font.name = brand["font"]

    return slide
```

---

## Adding a Logo

```python
from pptx.util import Inches

def add_logo(slide, logo_path, placement="bottom-left"):
    """Add a logo image to a slide."""
    if logo_path is None:
        return

    positions = {
        "bottom-left": {
            "left": Emu(300000),
            "top": Emu(6300000),
            "width": Emu(1500000),
        },
        "top-right": {
            "left": Emu(10500000),
            "top": Emu(200000),
            "width": Emu(1400000),
        },
        "top-left": {
            "left": Emu(300000),
            "top": Emu(200000),
            "width": Emu(1500000),
        },
    }

    pos = positions.get(placement, positions["bottom-left"])
    slide.shapes.add_picture(
        logo_path,
        left=pos["left"],
        top=pos["top"],
        width=pos["width"]
    )
```

---

## Adding a Footer

```python
def add_footer(slide, brand, footer_text, slide_number=None):
    """Add a footer bar to a content slide."""
    if not footer_text and slide_number is None:
        return

    # Footer text (left/center)
    if footer_text:
        ft = slide.shapes.add_textbox(
            Emu(457200), Emu(6500000), Emu(9000000), Emu(250000)
        )
        p = ft.text_frame.paragraphs[0]
        run = p.add_run()
        run.text = footer_text
        run.font.size = Pt(8)
        run.font.color.rgb = brand["text_muted"]
        run.font.name = brand["font"]

    # Slide number (right)
    if slide_number is not None:
        sn = slide.shapes.add_textbox(
            Emu(11500000), Emu(6500000), Emu(500000), Emu(250000)
        )
        p2 = sn.text_frame.paragraphs[0]
        p2.alignment = PP_ALIGN.RIGHT
        run2 = p2.add_run()
        run2.text = str(slide_number)
        run2.font.size = Pt(8)
        run2.font.color.rgb = brand["text_muted"]
        run2.font.name = brand["font"]
```

---

## Saving and Converting

```python
# Save
prs.save('output.pptx')

# Convert to PDF for QA
# python scripts/office/soffice.py --headless --convert-to pdf output.pptx

# Convert PDF to images
# pdftoppm -jpeg -r 150 output.pdf slide
# ls -1 "$PWD"/slide-*.jpg
```

---

## Safe Zone Reference

```python
# Use these constants throughout your code
MARGIN_LEFT   = Emu(457200)    # 0.5"
MARGIN_TOP    = Emu(457200)    # 0.5" (title area starts here)
CONTENT_TOP   = Emu(1300000)   # Below title, ~1.4"
MARGIN_RIGHT  = Emu(11734800)  # 0.5" from right (max left + width)
FOOTER_TOP    = Emu(6400000)   # Above footer zone
SLIDE_W       = Emu(12192000)  # 13.33"
SLIDE_H       = Emu(6858000)   # 7.5"
CONTENT_WIDTH = MARGIN_RIGHT - MARGIN_LEFT   # Safe content width
CONTENT_HEIGHT = FOOTER_TOP - CONTENT_TOP    # Safe content height
```
