---
name: brand-pptx
description: Use when creating branded PowerPoint presentations for any organization. Triggers on requests for "branded deck," "brand presentation," "company slides," "brand template," or any request to create a PPTX that should follow a specific company or brand's visual identity. On first use, this skill prompts the LLM to elicit brand information from the user before building anything.
---

# Brand PPTX Skill

## Purpose

This skill enables anyone to create a polished, on-brand PowerPoint presentation — even without a pre-configured brand template. It works in two modes:

| Mode | When to Use |
|------|-------------|
| **Elicitation Mode** | No brand profile exists yet — collect brand info first |
| **Execution Mode** | Brand profile is already loaded — build the deck |

Read `references/elicitation.md` for the full elicitation protocol.
Read `references/brand-rules.md` for brand encoding rules.
Read `references/pptx-templates.md` for python-pptx patterns.

---

## Step 1: Brand Elicitation (Always First)

**Before writing a single line of python-pptx code**, check if a brand profile exists in the conversation context. If not, trigger the elicitation flow defined in `references/elicitation.md`.

The elicitation flow collects:
1. Brand colors (primary, secondary, accent)
2. Typography (fonts, sizes, weights)
3. Logo (file provided or described)
4. Slide structure preferences (dark title slide, light content, section dividers)
5. Tone & voice (optional — for content generation)
6. Confidentiality footer (optional)
7. Template file (optional — user may provide a .pptx/.potx)

Once collected, encode the profile into a `BrandProfile` dict (see `references/brand-rules.md`) and proceed to execution.

---

## Step 2: Build the Deck

Use the brand profile to drive all python-pptx code. Read `references/pptx-templates.md` for patterns.

### Quick Reference

| Task | Guide |
|------|-------|
| Elicit brand info | `references/elicitation.md` |
| Encode brand profile | `references/brand-rules.md` |
| Build slides | `references/pptx-templates.md` |
| Convert template file | `scripts/convert_potx.py` |

---

## Design Principles

**Don't create boring slides.** Plain bullets on a white background won't impress anyone.

### Before Starting

- **Pick a bold, content-informed color palette**: The palette should feel designed for THIS brand. If swapping colors into a completely different presentation would still "work," the choices aren't specific enough.
- **Dominance over equality**: One color should dominate (60-70% visual weight), with 1-2 supporting tones and one sharp accent. Never give all colors equal weight.
- **Dark/light contrast**: Dark backgrounds for title + conclusion slides, light for content ("sandwich" structure). Or commit to dark throughout for a premium feel.
- **Commit to a visual motif**: Pick ONE distinctive element and repeat it — rounded image frames, icons in colored circles, thick single-side borders. Carry it across every slide.

### For Each Slide

**Every slide needs a visual element** — icon, chart, shape, or callout. Text-only slides are forgettable.

**Layout options:**
- Two-column (text left, visual right)
- Icon + text rows (icon in colored circle, bold header, description below)
- 2×2 or 2×3 grid cards
- Half-bleed color block with content overlay
- Large stat callouts (60–72pt number, small label below)
- Timeline or process flow (numbered steps, arrows)

### Avoid (Common Mistakes)

- **Don't repeat the same layout** — vary columns, cards, and callouts
- **Don't center body text** — left-align paragraphs; center only titles
- **Don't default to blue** — use the brand's actual colors
- **Don't create text-only slides** — always add a visual element
- **NEVER use accent lines under titles** — hallmark of AI-generated slides
- **Don't add decorative full-width colored bars** unless the brand explicitly uses them
- **Don't overflow text** — reduce font size or split slides before cutting content off

---

## QA (Required)

Your first render usually has issues — overlaps, overflow, misalignment. Find and fix those, then stop.

### Content QA

```bash
extract-text output.pptx
```

Check for missing content, typos, wrong order. Check for leftover placeholder text:

```bash
extract-text output.pptx | grep -iE "\bx{3,}\b|lorem|ipsum|\bTODO|\[insert"
```

### Visual QA

Convert slides to images and inspect:

```bash
python scripts/office/soffice.py --headless --convert-to pdf output.pptx
rm -f slide-*.jpg
pdftoppm -jpeg -r 150 output.pdf slide
ls -1 "$PWD"/slide-*.jpg
```

Use a subagent to inspect with fresh eyes:

```
Visually inspect these slides for user-visible defects.

Look for:
- Overlapping elements
- Text overflow or cut off at edges/box boundaries
- Elements too close (< 0.3" gaps)
- Uneven gaps or cramped sections
- Insufficient margin from slide edges (< 0.5")
- Low-contrast text or icons
- Leftover placeholder content

For each slide, list user-visible issues. Skip sub-pixel positioning.
```

### Verification Loop

1. Generate → Convert to images → Inspect
2. Fix issues
3. Re-verify only affected slides
4. Stop after one fix-and-verify cycle unless a new user-visible defect appears

---

## Dependencies

- `pip install python-pptx Pillow` — slide creation and thumbnail grids
- LibreOffice (`soffice`) — PDF conversion (via `scripts/office/soffice.py`)
- Poppler (`pdftoppm`) — PDF to images
