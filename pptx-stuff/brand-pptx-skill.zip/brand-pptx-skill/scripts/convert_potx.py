#!/usr/bin/env python3
"""
Convert a .potx PowerPoint template to .pptx for use with python-pptx.

Usage:
    python convert_potx.py <input.potx> <output.pptx>

python-pptx cannot open .potx files directly. This script copies the file
and patches the content type so it can be opened as a regular .pptx.
"""

import sys
import shutil
import zipfile
import tempfile
import os

def convert_potx_to_pptx(input_path, output_path):
    """Convert a .potx template to .pptx by patching content types."""
    
    # Copy to output
    shutil.copy2(input_path, output_path)
    
    # Patch [Content_Types].xml inside the zip
    tmpdir = tempfile.mkdtemp()
    try:
        with zipfile.ZipFile(output_path, 'r') as zin:
            zin.extractall(tmpdir)
        
        ct_path = os.path.join(tmpdir, '[Content_Types].xml')
        with open(ct_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        content = content.replace(
            'application/vnd.openxmlformats-officedocument.presentationml.template.main+xml',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml'
        )
        
        with open(ct_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # Repackage
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zout:
            for root, dirs, files in os.walk(tmpdir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, tmpdir)
                    zout.write(file_path, arcname)
        
        print(f"Converted: {input_path} -> {output_path}")
    finally:
        shutil.rmtree(tmpdir)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python convert_potx.py <input.potx> <output.pptx>")
        sys.exit(1)
    convert_potx_to_pptx(sys.argv[1], sys.argv[2])
